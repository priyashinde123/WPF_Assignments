﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLib.Entities
{
    public class commentbox
    {
         public  string heading { get; set; }

        public   string datetime { get; set; }
        public string message { get; set; }
        public string language { get; set; }
        public string person { get; set; }


    }
}
