﻿using DataLib.Entities;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLib.DataOperations
{
    public class mobile_Operations
    {
        private string _connectionString;
        public mobile_Operations(string connectionString)
        {
            _connectionString = connectionString;
        }
        public List<mobile> Getmoibles()
        {
            List<mobile> mobiles = new List<mobile>();

            using (SqlConnection connection = new SqlConnection(_connectionString))
            {

                SqlCommand command = new SqlCommand($"EXECUTE [dbo].[usp_GetMobile]", connection);

                connection.Open();


                SqlDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    mobile m = new mobile();
                    m.name = (string)reader[0];
                    m.price = (decimal)reader[1];
                    m.spec_score = (string)reader[2];



                    mobiles.Add(m);

                }

                connection.Close();

            }

            return mobiles;
        }
    }
}

