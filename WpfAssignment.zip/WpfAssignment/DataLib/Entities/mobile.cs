﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLib.Entities
{ 
    public  class mobile
    {
        public string name { get; set; }
        public decimal price { get; set; } 
        public string spec_score { get; set; }
    }
}
