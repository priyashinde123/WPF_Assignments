﻿using DataLib.DataOperations;
using DataLib.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfAssignment
{
    /// <summary>
    /// Interaction logic for CommentBox.xaml
    /// </summary>
    public partial class CommentBox : UserControl
    {
        private  static string connectingstring =@"Data Source=DESKTOP-7K173KI\SQL2016EXPRESS;Initial Catalog=wpf;Persist Security Info=True;User ID=sa;Password=aa";
        private static commentbox_operations operations = new commentbox_operations(connectingstring);

      public   List<commentbox> commentboxes;




        public CommentBox()
        {
            InitializeComponent();

            commentboxes = operations.Getcommentboxes();

            this.DataContext = this;
                
        }
    }
}
