﻿using DataLib.Entities;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLib.DataOperations
{
    public  class commentbox_operations
    {
        private string _connectionString;
        public commentbox_operations(string connectionString)
        {
            _connectionString = connectionString;
        }
        public List<commentbox> Getcommentboxes()
        {
            List<commentbox> comments = new List<commentbox>();

            using (SqlConnection connection = new SqlConnection(_connectionString))
            {

                SqlCommand command = new SqlCommand($"EXECUTE [dbo].[usp_GetCommentBox]", connection);

                connection.Open();


                SqlDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    commentbox c = new commentbox();
                    c.heading= (string)reader[0];
                    c.datetime = (string)reader[1];
                    c.message = (string)reader[2];
                    c.language = (string)reader[3];
                    c.person = (string)reader[4];


                    comments.Add(c);

                }

                connection.Close();

            }

            return comments;
        }
    }
}
